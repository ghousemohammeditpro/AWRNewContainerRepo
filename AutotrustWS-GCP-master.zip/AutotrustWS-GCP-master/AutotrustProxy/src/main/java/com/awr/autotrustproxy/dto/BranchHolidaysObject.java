package com.awr.autotrustproxy.dto;

public class BranchHolidaysObject {
    public BranchHolidaysObject() {
        super();
    }
    private String locationCode;
    private String groupId;
    private String dayOfWeek;
    private String dayNo;
    private String date;
    private String dayDescription;
    //    private String brand;
    //    private String vehicleType;
    //    private String customerWaiting;
    //    private String serviceAdvisorQuota;
    //    private String startDate;
    //    private String endDate;
    //    private String orgId;
    private String attributeCategory;
    private String attribute1;
    private String attribute2;
    private String attribute3;
    private String attribute4;
    private String attribute5;
    private String attribute6;
    private String attribute7;
    private String attribute8;
    private String attribute9;
    private String attribute10;

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupId() {
        return groupId;
    }

    //    public void setBrand(String brand) {
    //        this.brand = brand;
    //    }
    //
    //    public String getBrand() {
    //        return brand;
    //    }
    //
    //    public void setVehicleType(String vehicleType) {
    //        this.vehicleType = vehicleType;
    //    }
    //
    //    public String getVehicleType() {
    //        return vehicleType;
    //    }
    //
    //    public void setCustomerWaiting(String customerWaiting) {
    //        this.customerWaiting = customerWaiting;
    //    }
    //
    //    public String getCustomerWaiting() {
    //        return customerWaiting;
    //    }
    //
    //    public void setServiceAdvisorQuota(String serviceAdvisorQuota) {
    //        this.serviceAdvisorQuota = serviceAdvisorQuota;
    //    }
    //
    //    public String getServiceAdvisorQuota() {
    //        return serviceAdvisorQuota;
    //    }
    //
    //    public void setStartDate(String startDate) {
    //        this.startDate = startDate;
    //    }
    //
    //    public String getStartDate() {
    //        return startDate;
    //    }
    //
    //    public void setEndDate(String endDate) {
    //        this.endDate = endDate;
    //    }
    //
    //    public String getEndDate() {
    //        return endDate;
    //    }
    //
    //    public void setOrgId(String orgId) {
    //        this.orgId = orgId;
    //    }
    //
    //    public String getOrgId() {
    //        return orgId;
    //    }

    public void setAttributeCategory(String attributeCategory) {
        this.attributeCategory = attributeCategory;
    }

    public String getAttributeCategory() {
        return attributeCategory;
    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    public String getAttribute2() {
        return attribute2;
    }

    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    public String getAttribute3() {
        return attribute3;
    }

    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    public String getAttribute4() {
        return attribute4;
    }

    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }

    public String getAttribute5() {
        return attribute5;
    }

    public void setAttribute6(String attribute6) {
        this.attribute6 = attribute6;
    }

    public String getAttribute6() {
        return attribute6;
    }

    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
    }

    public String getAttribute7() {
        return attribute7;
    }

    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
    }

    public String getAttribute8() {
        return attribute8;
    }

    public void setAttribute9(String attribute9) {
        this.attribute9 = attribute9;
    }

    public String getAttribute9() {
        return attribute9;
    }

    public void setAttribute10(String attribute10) {
        this.attribute10 = attribute10;
    }

    public String getAttribute10() {
        return attribute10;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayNo(String dayNo) {
        this.dayNo = dayNo;
    }

    public String getDayNo() {
        return dayNo;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDayDescription(String dayDescription) {
        this.dayDescription = dayDescription;
    }

    public String getDayDescription() {
        return dayDescription;
    }
}
