# AutotrustWS-GCP
This project is for Autotrust services deployed in GCP
