package com.awr.autotrustservice.dto;

public class IncidentObject {
    public IncidentObject() {
        super();
    }
    private String incicdentTypeId;
//    private String incidentSubtype;
    private String name;
    private String description;
//    private String statusGroupId;
    private String attribute1;
    private String attribute2;
    private String attribute3;
    private String attribute4;
    private String attribute5;
    private String attribute6;
    private String attribute7;
    private String attribute8;
    private String attribute9;
    private String attribute10;

    public void setIncicdentTypeId(String incicdentTypeId) {
        this.incicdentTypeId = incicdentTypeId;
    }

    public String getIncicdentTypeId() {
        return incicdentTypeId;
    }

//    public void setIncidentSubtype(String incidentSubtype) {
//        this.incidentSubtype = incidentSubtype;
//    }
//
//    public String getIncidentSubtype() {
//        return incidentSubtype;
//    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

//    public void setStatusGroupId(String statusGroupId) {
//        this.statusGroupId = statusGroupId;
//    }
//
//    public String getStatusGroupId() {
//        return statusGroupId;
//    }

    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
    }

    public String getAttribute1() {
        return attribute1;
    }

    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
    }

    public String getAttribute2() {
        return attribute2;
    }

    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
    }

    public String getAttribute3() {
        return attribute3;
    }

    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
    }

    public String getAttribute4() {
        return attribute4;
    }

    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
    }

    public String getAttribute5() {
        return attribute5;
    }

    public void setAttribute6(String attribute6) {
        this.attribute6 = attribute6;
    }

    public String getAttribute6() {
        return attribute6;
    }

    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
    }

    public String getAttribute7() {
        return attribute7;
    }

    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
    }

    public String getAttribute8() {
        return attribute8;
    }

    public void setAttribute9(String attribute9) {
        this.attribute9 = attribute9;
    }

    public String getAttribute9() {
        return attribute9;
    }

    public void setAttribute10(String attribute10) {
        this.attribute10 = attribute10;
    }

    public String getAttribute10() {
        return attribute10;
    }
}
