package com.awr.autotrustservice.dto;

public class VehicleImage {
    public VehicleImage() {
        super();
    }
    private String imageUrl;


    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
