package com.awr.autotrustservice.dto;

public class AddonObject {
    public AddonObject() {
        super();
    }
    private String orgId;
    private String reservationId;
    private String addonId;

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setReservationId(String reservationId) {
        this.reservationId = reservationId;
    }

    public String getReservationId() {
        return reservationId;
    }

    public void setAddonId(String addonId) {
        this.addonId = addonId;
    }

    public String getAddonId() {
        return addonId;
    }
}
