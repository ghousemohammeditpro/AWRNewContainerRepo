package com.awr.autotrustservice.request;

public class GenericRequest {
    public GenericRequest() {
        super();
    }
    private String buId;
//    private String source;

    public void setBuId(String buId) {
        this.buId = buId;
    }

    public String getBuId() {
        return buId;
    }

//    public void setSource(String source) {
//        this.source = source;
//    }
//
//    public String getSource() {
//        return source;
//    }
}
